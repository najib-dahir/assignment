function calculateTotalTarget(startDate, endDate, totalAnnualTarget) {
    // Convert the input strings into Date objects
    const start = new Date(startDate);
    const end = new Date(endDate);

    // Function to get all days in a month excluding Fridays
    function getWorkingDaysInMonth(year, month) {
        let daysInMonth = new Date(year, month + 1, 0).getDate(); // Get total days in the month
        let workingDays = 0;

        for (let day = 1; day <= daysInMonth; day++) {
            let date = new Date(year, month, day);
            // Check if the day is not Friday (5)
            if (date.getDay() !== 5) {
                workingDays++;
            }
        }
        return workingDays;
    }

    // Function to get the working days within a range for a given month
    function getWorkingDaysInRange(year, month, startDay, endDay) {
        let workingDays = 0;
        for (let day = startDay; day <= endDay; day++) {
            let date = new Date(year, month, day);
            if (date.getDay() !== 5) { // Exclude Fridays
                workingDays++;
            }
        }
        return workingDays;
    }

    let current = new Date(start);
    let daysExcludingFridays = [];
    let daysWorkedExcludingFridays = [];
    let totalWorkingDays = 0;

    // Loop through each month between startDate and endDate
    while (current <= end) {
        let year = current.getFullYear();
        let month = current.getMonth();

        // Get total working days in the current month (excluding Fridays)
        let totalDaysInMonth = getWorkingDaysInMonth(year, month);
        daysExcludingFridays.push(totalDaysInMonth);

        // Calculate the working days for the specific date range in the current month
        let startDay = (current.getMonth() === start.getMonth() && current.getFullYear() === start.getFullYear()) 
            ? start.getDate() : 1;

        let endDay = (current.getMonth() === end.getMonth() && current.getFullYear() === end.getFullYear()) 
            ? end.getDate() : new Date(year, month + 1, 0).getDate();

        let workedDays = getWorkingDaysInRange(year, month, startDay, endDay);
        daysWorkedExcludingFridays.push(workedDays);

        totalWorkingDays += workedDays;

        // Move to the next month
        current.setMonth(current.getMonth() + 1);
        current.setDate(1); // Reset to the 1st of the next month
    }

    // Calculate the monthly targets based on the working days
    let monthlyTargets = daysWorkedExcludingFridays.map(workedDays => 
        (workedDays / totalWorkingDays) * totalAnnualTarget
    );

    let totalTarget = monthlyTargets.reduce((acc, target) => acc + target, 0);

    
    return {
        daysExcludingFridays,
        daysWorkedExcludingFridays,
        monthlyTargets,
        totalTarget: totalTarget
    };
}

// Example usage:
const result = calculateTotalTarget('2024-01-01', '2024-03-31', 5220);
console.log(result);


